Cypress.on('uncaught:exception', (err, runnable) => {
    // returning false here prevents Cypress from
    // failing the test
    return false
  })

// Cypress.env('Link')
// Cypress.env('username')
// Cypress.env('password')


describe('Adding App_Id', () => {
    it('Visit link', () => {
        cy.visit(Cypress.env('Link'));
        cy.get('.log-in > .table > .table-cell > form > :nth-child(1) > .form-control').type(Cypress.env('Ethicalusername'))
        cy.get('.log-in > .table > .table-cell > form > :nth-child(2) > .form-control').type(Cypress.env('Ethicalpassword'))
        cy.get('.log-in > .table > .table-cell > form > .text-center > .btn').click()
    })
    // it('Login', () => {
    //     Cypress.config()
    //     cy.visit("https://staging-stack-crp-5084.riskprofiler.io/")
    //     cy.get('.log-in > .table > .table-cell > form > :nth-child(1) > .form-control').click() .type(Cypress.env('email-id '))
    //     cy.get('.log-in > .table > .table-cell > form > :nth-child(2) > .form-control').click().type(Cypress.env('password'))
    //     cy.get('.log-in > .table > .table-cell > form > .text-center > .btn').should('be.visible').click()
    //     cy.wait(2000)

    // });
    
})
